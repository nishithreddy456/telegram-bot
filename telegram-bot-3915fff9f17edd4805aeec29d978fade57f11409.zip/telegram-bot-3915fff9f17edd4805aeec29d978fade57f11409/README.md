This telegram bot has love-calculator
Responsive for hi,stciker,emojis

/check-love-calculator
markdown
/html
/custom-photos--api
/inline-photos
